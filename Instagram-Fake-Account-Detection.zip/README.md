# Instagram Fake vs Genuine Account Detection

This project uses a Decision Tree classifier to identify fake Instagram accounts based on account statistics.

## 📊 Dataset

- **train.csv**: Contains labeled training data
- **test.csv**: Contains labeled test data

## 🧠 Model Used

- Decision Tree Classifier
- Evaluation using Accuracy, Confusion Matrix, and Classification Report

## 📈 Features Analyzed

- Number of followers
- Number of following
- Number of posts
- Engagement metrics

## 📌 Visualizations

- Class distribution
- Correlation matrix
- Decision tree plot
- Feature importance

## 📂 Files

- `instagram_fake_account_detection.py`: Project code
- `train.csv`, `test.csv`: Dataset files

## 🔍 Future Work

- Try other models like Random Forest, SVM, XGBoost
- Hyperparameter tuning
- Add more features like bio length, username patterns, etc.

---

**Author:** Varshini Yadav Nasaram  
