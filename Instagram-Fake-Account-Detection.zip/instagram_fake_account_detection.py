# Instagram Fake vs Genuine Account Detection Project

# Step 1: Import Libraries
import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt

from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix

# Step 2: Load Data
train_df = pd.read_csv('train.csv')
test_df = pd.read_csv('test.csv')

# Step 3: Explore Data
print(train_df.head())
print(train_df.describe())
print(train_df.isnull().sum())

# Step 4: EDA - Class Distribution
sns.countplot(x='fake', data=train_df)
plt.title('Fake vs Genuine Accounts')
plt.show()

# Correlation Matrix
plt.figure(figsize=(10, 8))
sns.heatmap(train_df.corr(), annot=True, cmap='coolwarm')
plt.title("Feature Correlation Matrix")
plt.show()

# Step 5: Prepare Data
train_df['#followers_bins'] = pd.cut(train_df['#followers'],
                                     bins=[0, 25, 50, 100, 200, 300, 400, 500, 1000, 5000, 10000])

X = train_df.drop(['#followers_bins', 'fake'], axis=1)
y = train_df['fake']

X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)

# Step 6: Train Model
model = DecisionTreeClassifier()
model.fit(X_train, y_train)

# Step 7: Validation Performance
y_val_pred = model.predict(X_val)
print("Validation Accuracy:", accuracy_score(y_val, y_val_pred))
print("Confusion Matrix:\n", confusion_matrix(y_val, y_val_pred))
print("Classification Report:\n", classification_report(y_val, y_val_pred))

# Step 8: Visualize the Decision Tree
from sklearn import tree
plt.figure(figsize=(20, 20))
tree.plot_tree(model, filled=True, feature_names=X.columns, class_names=['genuine', 'fake'], rounded=True)
plt.show()

# Step 9: Feature Importances
plt.figure(figsize=(10, 6))
plt.barh(X.columns, model.feature_importances_)
plt.title("Feature Importances")
plt.show()

# Step 10: Test Set Evaluation
X_test_final = test_df.drop(['fake'], axis=1)
y_test_final = test_df['fake']
y_test_pred = model.predict(X_test_final)

print("Test Accuracy:", accuracy_score(y_test_final, y_test_pred))
print("Test Confusion Matrix:\n", confusion_matrix(y_test_final, y_test_pred))
print("Test Classification Report:\n", classification_report(y_test_final, y_test_pred))

# Final Feature Importance on Test
plt.figure(figsize=(10, 6))
plt.barh(X_test_final.columns, model.feature_importances_)
plt.title("Test Feature Importances")
plt.show()
